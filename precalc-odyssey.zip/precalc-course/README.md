# Precalc Odyssey

Narrative-driven Precalculus course for high school students.

## Structure
- Static HTML/CSS/JS site
- Run locally: `python3 -m http.server` in the directory
- Deploy to GitHub Pages

## Units
1. Functions as Machines
2. Polynomials & Rationals
etc.

## Development
All assets local. Use vanilla tech.